# -*- mode: python ; coding: utf-8 -*-
# FinStruct PyInstaller spec

import os
from pathlib import Path

block_cipher = None

# Sentence-transformers model path (bundled)
APPDATA = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
MODEL_DIR = APPDATA / "FinStruct" / "models" / "all-MiniLM-L6-v2"

datas = []
if MODEL_DIR.exists():
    datas.append((str(MODEL_DIR), "models/all-MiniLM-L6-v2"))

a = Analysis(
    ["finstruct_app.py"],
    pathex=["."],
    binaries=[],
    datas=datas,
    hiddenimports=[
        "sklearn.utils._cython_blas",
        "sklearn.neighbors.typedefs",
        "sklearn.neighbors.quad_tree",
        "sklearn.tree._utils",
        "sentence_transformers",
        "anthropic",
        "lxml",
        "openpyxl",
        "reportlab",
        "docx",
        "cryptography",
        "keyring",
        "tkinter",
        "tkinter.ttk",
        "tkinter.filedialog",
        "tkinter.messagebox",
        "tkinter.simpledialog",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["matplotlib", "numpy.random._examples", "test"],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="FinStruct",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,        # No console window
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="FinStruct",
)
