"""FinStruct — standalone entry point."""

import sys
import logging
import tkinter as tk
from pathlib import Path

# Ensure bundled libs are found when running as PyInstaller .exe
if getattr(sys, "frozen", False):
    base = Path(sys._MEIPASS)
    sys.path.insert(0, str(base))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)

def main():
    root = tk.Tk()
    try:
        root.iconbitmap(default="")
    except Exception:
        pass

    from finstruct.gui.main_window import MainWindow
    app = MainWindow(root)          # noqa: F841

    root.protocol("WM_DELETE_WINDOW", root.quit)
    root.mainloop()


if __name__ == "__main__":
    main()
