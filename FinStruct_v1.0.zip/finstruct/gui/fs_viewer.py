"""FS Viewer — tabbed spreadsheet view of all generated statements."""

from __future__ import annotations
import tkinter as tk
from tkinter import ttk, messagebox
from ..config import THEME as T
from ..core.fs_engine import FSDocument, FSLine
from ..gui.theme import primary_btn, secondary_btn, label
from .fs_grid_view import EditableGrid


def _fmt(v: float | None) -> str:
    if v is None or v == 0:
        return "-"
    return f"{v:,.2f}"


class FSViewer(ttk.Frame):
    def __init__(self, parent, doc: FSDocument, db, on_proceed: callable = None):
        super().__init__(parent)
        self._doc = doc
        self._db  = db
        self._on_proceed = on_proceed
        self._grids: dict[str, EditableGrid] = {}
        self._build()

    def _build(self):
        top = ttk.Frame(self)
        top.pack(fill="x", padx=8, pady=6)
        label(top, "6.  Financial Statements", style="Sec.TLabel").pack(side="left")
        secondary_btn(top, "Save Overrides", command=self._save_overrides).pack(side="left", padx=8)
        primary_btn(top, "→ Generate Notes  F10", command=self._go_notes).pack(side="right", padx=4)

        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=8, pady=4)

        statement_map = [
            ("bs", "Balance Sheet"),
            ("pl", "Profit & Loss"),
            ("ie", "Income & Expenditure"),
            ("rp", "Receipt & Payment"),
            ("cf", "Cash Flow"),
        ]
        for attr, title in statement_map:
            lines = getattr(self._doc, attr, [])
            if not lines:
                continue
            frame = ttk.Frame(nb)
            nb.add(frame, text=title)
            grid = self._make_grid(frame, lines, attr)
            self._grids[attr] = grid

    def _make_grid(self, parent, lines: list[FSLine], section: str) -> EditableGrid:
        cols = [
            ("label", "Particulars",        420, "w"),
            ("note",  "Note",                50, "center"),
            ("cy",    "Current Year ₹",     140, "e"),
            ("py",    "Previous Year ₹",    140, "e"),
        ]
        grid = EditableGrid(parent, columns=cols,
                            on_cell_change=lambda iid, col, val:
                                self._on_cell_edit(section, iid, col, val),
                            editable_cols={"cy", "py"})
        grid.pack(fill="both", expand=True)

        rows = []
        for i, ln in enumerate(lines):
            indent = "    " * ln.indent
            cy_s = _fmt(ln.cy) if ln.row_type not in ("SECTION","HEADER","BLANK","TEXT") else ""
            py_s = _fmt(ln.py) if ln.row_type not in ("SECTION","HEADER","BLANK","TEXT") else ""
            note_s = str(ln.note) if ln.note else ""
            tag_map = {
                "HEADER":  "header",
                "SECTION": "section",
                "TOTAL":   "total",
                "GRAND":   "grand",
                "BLANK":   "",
                "TEXT":    "red",
            }
            tag = tag_map.get(ln.row_type, "alt" if i % 2 == 0 else "")
            rows.append({
                "iid":    f"{section}_{i}",
                "tag":    tag,
                "values": [indent + ln.label, note_s, cy_s, py_s],
            })
        grid.load_rows(rows)
        return grid

    def _on_cell_edit(self, section: str, iid: str, col: str, new_val: str):
        try:
            v = float(str(new_val).replace(",", ""))
        except ValueError:
            return
        # Store override — extract line index from iid
        try:
            idx = int(iid.split("_")[1])
        except (IndexError, ValueError):
            return
        lines = getattr(self._doc, section.lower() if section not in ("ie","rp","cf") else section, [])
        if idx < len(lines):
            ln = lines[idx]
            if col == "cy":
                ln.cy = v
            elif col == "py":
                ln.py = v

    def _save_overrides(self):
        for section, grid in self._grids.items():
            rows = grid.get_all_rows()
            lines = getattr(self._doc, section, [])
            for i, (row, ln) in enumerate(zip(rows, lines)):
                try:
                    cy = float(str(row[2]).replace(",","")) if row[2] not in ("","-") else ln.cy
                    py = float(str(row[3]).replace(",","")) if row[3] not in ("","-") else ln.py
                    if cy != ln.cy or py != ln.py:
                        self._db.set_override(section, f"{section}_{i}", cy, py, "Manual edit")
                except (ValueError, IndexError):
                    pass
        messagebox.showinfo("Saved", "Overrides saved.")

    def _go_notes(self):
        if self._on_proceed:
            self._on_proceed()
